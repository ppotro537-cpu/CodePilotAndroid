package com.example.codepilot

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF0C1020)
private val Panel = Color(0xFF171D31)
private val Accent = Color(0xFF9B8CFF)
private val Mint = Color(0xFF6FE3C1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CodePilotApp(this) }
    }
}

private data class ChatMessage(val role: String, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CodePilotApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("codepilot", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var projectUri by remember { mutableStateOf<Uri?>(null) }
    var files by remember { mutableStateOf(listOf<Pair<String, Uri>>()) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("") }
    var editorText by remember { mutableStateOf("") }
    var pendingSave by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1").orEmpty()) }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini").orEmpty()) }
    var apiKey by remember { mutableStateOf(prefs.getString("apiKey", "").orEmpty()) }
    var systemPrompt by remember { mutableStateOf("Eres un agente de programación. Explica tus propuestas en español. No afirmes haber modificado archivos ni ejecutado comandos si no lo hiciste.") }
    var terminalInput by remember { mutableStateOf("pwd") }
    var terminalOutput by remember { mutableStateOf("Terminal restringida: comandos de solo lectura dentro del sandbox de la app.") }
    val messages = remember { mutableStateListOf(ChatMessage("assistant", "¡Hola! Soy CodePilot. Selecciona un proyecto y dime qué quieres construir. Esta versión inicial no aplica cambios automáticamente.")) }
    val scope = rememberCoroutineScope()
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            projectUri = uri
            files = listFiles(context, uri)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, secondary = Mint, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("CodePilot", style = MaterialTheme.typography.titleLarge)
                            Text("Agente de programación · prototipo 0.1", style = MaterialTheme.typography.labelSmall, color = Mint)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White),
                    actions = { IconButton(onClick = { tab = 3 }) { Icon(Icons.Default.Settings, "Ajustes") } }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("Chat", "Archivos", "Terminal", "Ajustes")
                    val icons = listOf(Icons.Default.Chat, Icons.Default.FolderOpen, Icons.Default.Terminal, Icons.Default.Settings)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent)
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> ChatScreen(
                    Modifier.padding(padding), messages, draft, { draft = it }, busy,
                    onSend = {
                        val prompt = draft.trim()
                        if (prompt.isNotEmpty() && !busy) {
                            messages.add(ChatMessage("user", prompt))
                            draft = ""; busy = true
                            scope.launch {
                                val contextText = if (selectedName.isNotBlank()) "\nArchivo actualmente abierto ($selectedName):\n${editorText.take(12000)}" else ""
                                val result = withContext(Dispatchers.IO) {
                                    callModel(endpoint, model, apiKey, systemPrompt, messages.toList(), contextText)
                                }
                                messages.add(ChatMessage("assistant", result))
                                busy = false
                            }
                        }
                    }
                )
                1 -> FilesScreen(
                    Modifier.padding(padding), projectUri != null, files, selectedName, editorText,
                    onChoose = { folderPicker.launch(null) },
                    onRefresh = { projectUri?.let { files = listFiles(context, it) } },
                    onOpen = { name, uri ->
                        selectedName = name; selectedUri = uri
                        editorText = readUri(context, uri)
                    },
                    onTextChange = { editorText = it },
                    onSave = { pendingSave = true }
                )
                2 -> TerminalScreen(Modifier.padding(padding), terminalInput, { terminalInput = it }, terminalOutput, {
                    terminalOutput = runSafeCommand(context, terminalInput)
                })
                else -> SettingsScreen(
                    Modifier.padding(padding), endpoint, { endpoint = it }, model, { model = it }, apiKey, { apiKey = it },
                    onSave = {
                        prefs.edit().putString("endpoint", endpoint.trim().trimEnd('/'))
                            .putString("model", model.trim()).putString("apiKey", apiKey).apply()
                    }
                )
            }
        }
        if (pendingSave) {
            AlertDialog(
                onDismissRequest = { pendingSave = false },
                title = { Text("¿Guardar cambios?") },
                text = { Text("Se sobrescribirá el archivo $selectedName. Asegúrate de tener una copia si contiene trabajo importante.") },
                confirmButton = {
                    TextButton(onClick = {
                        val uri = selectedUri
                        if (uri != null) writeUri(context, uri, editorText)
                        pendingSave = false
                        projectUri?.let { files = listFiles(context, it) }
                    }) { Text("Guardar") }
                },
                dismissButton = { TextButton(onClick = { pendingSave = false }) { Text("Cancelar") } },
                containerColor = Panel
            )
        }
    }
}

@Composable
private fun ChatScreen(
    modifier: Modifier, messages: List<ChatMessage>, draft: String, onDraft: (String) -> Unit,
    busy: Boolean, onSend: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Mint)
                Spacer(Modifier.width(8.dp))
                Text("Planifica · programa · revisa", style = MaterialTheme.typography.labelLarge)
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                val user = msg.role == "user"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (user) Color(0xFF292748) else Panel)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(if (user) "TÚ" else "CODEPILOT", color = if (user) Accent else Mint, style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(msg.text)
                    }
                }
            }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = draft, onValueChange = onDraft, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Describe una tarea de programación…") }, minLines = 2, maxLines = 5,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray)
        )
        Spacer(Modifier.height(6.dp))
        Button(onClick = onSend, enabled = !busy && draft.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "Pensando…" else "Enviar")
        }
    }
}

@Composable
private fun FilesScreen(
    modifier: Modifier, hasProject: Boolean, files: List<Pair<String, Uri>>, selectedName: String,
    editorText: String, onChoose: () -> Unit, onRefresh: () -> Unit,
    onOpen: (String, Uri) -> Unit, onTextChange: (String) -> Unit, onSave: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onChoose, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Elegir proyecto") }
            OutlinedButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null) }
        }
        if (!hasProject) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Elige una carpeta de proyecto para explorar y editar archivos.", color = Color.LightGray)
            }
        } else {
            Text("${files.size} archivos de texto encontrados", color = Mint, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn(Modifier.weight(if (selectedName.isNotBlank()) 0.32f else 1f)) {
                items(files) { (name, uri) ->
                    Row(Modifier.fillMaxWidth().clickable { onOpen(name, uri) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = if (name == selectedName) Accent else Color.LightGray)
                        Spacer(Modifier.width(8.dp)); Text(name, color = if (name == selectedName) Accent else Color.White)
                    }
                    HorizontalDivider(color = Color(0xFF30364B))
                }
            }
            if (selectedName.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(selectedName, modifier = Modifier.weight(1f), color = Mint)
                    Button(onClick = onSave) { Text("Guardar") }
                }
                OutlinedTextField(
                    value = editorText, onValueChange = onTextChange, modifier = Modifier.weight(1f).fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
                    minLines = 6, maxLines = 30,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent)
                )
            }
        }
    }
}

@Composable
private fun TerminalScreen(
    modifier: Modifier, command: String, onCommand: (String) -> Unit, output: String, onRun: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Text("Terminal restringida", style = MaterialTheme.typography.titleMedium, color = Mint)
        Text("Solo admite pwd, ls, find y cat dentro del almacenamiento privado de CodePilot.", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = command, onValueChange = onCommand, modifier = Modifier.fillMaxWidth(), label = { Text("Comando permitido") })
        Button(onClick = onRun, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Ejecutar") }
        Text(output, modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF05070D)).padding(12.dp).verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, color = Mint)
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier, endpoint: String, onEndpoint: (String) -> Unit, model: String, onModel: (String) -> Unit,
    apiKey: String, onApiKey: (String) -> Unit, onSave: () -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Motor de IA", style = MaterialTheme.typography.titleLarge)
        Text("Usa un endpoint compatible con OpenAI Chat Completions. Para un servidor local accesible por Wi‑Fi, usa la IP del equipo servidor, no localhost.", color = Color.LightGray)
        OutlinedTextField(endpoint, onEndpoint, modifier = Modifier.fillMaxWidth(), label = { Text("URL base") }, singleLine = true)
        OutlinedTextField(model, onModel, modifier = Modifier.fillMaxWidth(), label = { Text("Nombre del modelo") }, singleLine = true)
        OutlinedTextField(apiKey, onApiKey, modifier = Modifier.fillMaxWidth(), label = { Text("Clave API (opcional para algunos servidores)") }, singleLine = true)
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Guardar configuración") }
        Text("Privacidad: la clave se guarda en preferencias privadas de la app, pero no está cifrada en esta versión de prototipo. No compartas el teléfono ni el APK con la clave configurada.", color = Color(0xFFFFC76A))
        Text("Siguiente etapa: Git, diff/patches, permisos por herramienta, modelos locales integrados y pruebas de compilación.", color = Color.LightGray)
    }
}

private fun callModel(
    endpoint: String, model: String, apiKey: String, systemPrompt: String,
    messages: List<ChatMessage>, contextText: String
): String {
    if (endpoint.isBlank() || model.isBlank()) return "Configura una URL base y un nombre de modelo en Ajustes."
    return try {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", systemPrompt + contextText))
        messages.takeLast(16).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.2)
        val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
        val reqBuilder = Request.Builder()
            .url(endpoint.trimEnd('/') + "/chat/completions")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
        if (apiKey.isNotBlank()) reqBuilder.header("Authorization", "Bearer $apiKey")
        client.newCall(reqBuilder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "Error HTTP ${response.code}: ${raw.take(1200)}"
            else JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?: "La respuesta del proveedor no contiene choices[0].message.content:\n${raw.take(1000)}"
        }
    } catch (e: Exception) {
        "No se pudo conectar: ${e.message ?: e.javaClass.simpleName}. Revisa la URL, conexión, modelo y proveedor."
    }
}

private fun listFiles(context: Context, root: Uri): List<Pair<String, Uri>> {
    val out = mutableListOf<Pair<String, Uri>>()
    fun walk(dir: Uri, depth: Int) {
        if (depth > 5 || out.size > 300) return
        val children = try { androidx.documentfile.provider.DocumentFile.fromTreeUri(context, dir)?.listFiles() ?: emptyArray() } catch (_: Exception) { emptyArray() }
        children.forEach { f ->
            if (f.isDirectory) walk(f.uri, depth + 1)
            else if (f.isFile && f.name != null && (f.name!!.matches(Regex(".*\\.(kt|java|xml|gradle|kts|json|md|txt|py|js|ts|html|css|yml|yaml|sh|properties)$", RegexOption.IGNORE_CASE)))) {
                out.add(f.name!! to f.uri)
            }
        }
    }
    walk(root, 0)
    return out.sortedBy { it.first.lowercase() }
}

private fun readUri(context: Context, uri: Uri): String = try {
    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(200_000) }.orEmpty()
} catch (e: Exception) { "No se pudo leer el archivo: ${e.message}" }

private fun writeUri(context: Context, uri: Uri, text: String) {
    try { context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(text) } } catch (_: Exception) {}
}

private fun runSafeCommand(context: Context, raw: String): String {
    val trimmed = raw.trim()
    val parts = trimmed.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (parts.isEmpty()) return "Escribe un comando."
    val allowed = setOf("pwd", "ls", "find", "cat")
    if (parts[0] !in allowed) return "Bloqueado. Comandos permitidos: ${allowed.joinToString()}."
    if (parts.any { it == ";" || it == "&&" || it == "||" || it == "|" || it == ">" || it == ">>" || it == "`" || it.contains("$(") }) {
        return "Bloqueado: no se permiten encadenamientos ni redirecciones."
    }
    // Keep every argument relative to the private workspace; reject path traversal.
    if (parts.drop(1).any { arg ->
            arg.startsWith("/") || arg == ".." || arg.startsWith("../") ||
            arg.contains("/../") || arg.contains("\\\\") || arg.contains("\u0000")
        }) {
        return "Bloqueado: solo se admiten rutas relativas dentro del workspace privado."
    }
    return try {
        val root = File(context.filesDir, "workspace").apply { mkdirs() }.canonicalFile
        val args = when (parts[0]) {
            "pwd" -> listOf("pwd")
            "ls" -> listOf("ls") + parts.drop(1)
            "find" -> listOf("find") + parts.drop(1)
            "cat" -> listOf("cat") + parts.drop(1)
            else -> return "Comando no permitido."
        }
        val proc = ProcessBuilder(args).directory(root).redirectErrorStream(true).start()
        if (!proc.waitFor(3, TimeUnit.SECONDS)) { proc.destroyForcibly(); "Tiempo agotado." }
        else proc.inputStream.bufferedReader().use { it.readText().take(8000) }
    } catch (e: Exception) { "Error: ${e.message}" }
}
